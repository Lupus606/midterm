from Crypto.Random import random
from Crypto.Util.number import getPrime

p = getPrime(256)
g = 2

# Alice
a = random.randint(1, p-1)
A = pow(g, a, p)

# Bob
b = random.randint(1, p-1)
B = pow(g, b, p)

shared_A = pow(B, a, p)
shared_B = pow(A, b, p)

print("Alice Public Key:", A)
print("Bob Public Key:", B)
print("Shared Secret (Alice):", shared_A)
print("Shared Secret (Bob):", shared_B)
