from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import hashlib

# AES key and IV from passphrase
passphrase = "MyPass123"
key = hashlib.md5(passphrase.encode()).digest()  # 128-bit key
iv = get_random_bytes(16)

# Read plaintext
with open("secret.txt", "rb") as f:
    plaintext = f.read()

# Padding
pad_len = 16 - len(plaintext) % 16
padded = plaintext + bytes([pad_len]) * pad_len

cipher = AES.new(key, AES.MODE_CBC, iv)
ciphertext = cipher.encrypt(padded)

with open("secret.enc", "wb") as f:
    f.write(iv + ciphertext)
