import hashlib, hmac

# SHA-256 hash
with open("data.txt", "rb") as f:
    data = f.read()
print("SHA-256:", hashlib.sha256(data).hexdigest())

# HMAC
key = b"secretkey123"
mac = hmac.new(key, data, hashlib.sha256)
print("HMAC:", mac.hexdigest())
