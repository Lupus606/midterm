from Crypto.Signature import DSS
from Crypto.Hash import SHA256
from Crypto.PublicKey import ECC

# Generate keys
key = ECC.generate(curve='P-256')
with open("ecc_private.pem", "wt") as f:
    f.write(key.export_key(format="PEM"))
with open("ecc_public.pem", "wt") as f:
    f.write(key.public_key().export_key(format="PEM"))

# Load private key
with open("ecc.txt", "rb") as f:
    message = f.read()

h = SHA256.new(message)
signer = DSS.new(key, 'fips-186-3')
signature = signer.sign(h)

with open("ecc.sig", "wb") as f:
    f.write(signature)

# Verify
verifier = DSS.new(key.public_key(), 'fips-186-3')
try:
    verifier.verify(h, signature)
    print("Signature is valid.")
except ValueError:
    print("Signature is invalid.")
