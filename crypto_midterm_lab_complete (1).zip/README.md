# Applied Cryptography – Midterm Lab Exam

## Task 1 – AES Encryption

### AES-128-CBC using Python:
- Used MD5 hash of passphrase for 128-bit key
- CBC mode with random IV
- Encrypted file: `secret.enc`

### Decryption approach:
- Extract IV + decrypt with same passphrase

---

## Task 2 – ECC Signature

### Key Generation:
- Curve: prime256v1 (P-256)

### Signing:
- Signed `ecc.txt` using ECDSA

### Verification:
- Used DSS (FIPS-186-3) for verification

---

## Task 3 – Hashing and HMAC

- SHA-256 hash of `data.txt`
- HMAC using key: `secretkey123`
- Modified message changes HMAC

---

## Task 4 – Diffie-Hellman

- Simulated DH key exchange
- Both parties derived identical shared secret

---

## How to Run:

1. Install Python and `pycryptodome`:
```
pip install pycryptodome
```

2. Run each script from its directory:
```
python aes_script.py
python ecc_sign_verify.py
python hash_hmac.py
python dh_exchange.py
```
